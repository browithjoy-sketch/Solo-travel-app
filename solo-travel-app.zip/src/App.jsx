import { useState } from "react";
import { motion } from "framer-motion";

export default function App() {
  const trips = [
    { id: 1, name: "Goa Beach Escape", price: "₹4,999", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e" },
    { id: 2, name: "Manali Mountain Ride", price: "₹6,499", img: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee" },
    { id: 3, name: "Jaipur Heritage Tour", price: "₹3,999", img: "https://images.unsplash.com/photo-1548013146-72479768bada" }
  ];

  const [selected, setSelected] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [bookingDone, setBookingDone] = useState(false);

  const handleBook = () => {
    if (name && email) setBookingDone(true);
  };

  return (
    <div style={{ padding: 20 }}>
      {!selected && (
        <>
          <h1 style={{ textAlign: "center" }}>Solo Travel Trips</h1>
          <p style={{ textAlign: "center", color: "gray" }}>Pick your destination</p>

          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            {trips.map((t) => (
              <div
                key={t.id}
                onClick={() => setSelected(t)}
                style={{
                  background: "white",
                  borderRadius: 12,
                  padding: 10,
                  cursor: "pointer",
                  boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
                }}
              >
                <img src={t.img} style={{ width: "100%", borderRadius: 12 }} />
                <h2>{t.name}</h2>
                <p>{t.price}</p>
              </div>
            ))}
          </div>
        </>
      )}

      {selected && !bookingDone && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <img src={selected.img} style={{ width: "100%", borderRadius: 12 }} />
          <h2>{selected.name}</h2>
          <p>{selected.price}</p>

          <input
            placeholder="Your Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={{ width: "100%", padding: 10, marginTop: 10 }}
          />

          <input
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: "100%", padding: 10, marginTop: 10 }}
          />

          <button onClick={handleBook} style={{ width: "100%", padding: 12, marginTop: 10, background: "#000", color: "white" }}>Confirm Booking</button>
          <button onClick={() => setSelected(null)} style={{ width: "100%", padding: 12, marginTop: 10 }}>Back</button>
        </motion.div>
      )}

      {bookingDone && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ textAlign: "center", padding: 20 }}>
          <h2>Booking Successful!</h2>
          <p>Pay manually via UPI. Admin will confirm booking.</p>
          <button
            onClick={() => {
              setSelected(null);
              setBookingDone(false);
            }}
            style={{ marginTop: 20, padding: 12, width: "100%" }}
          >
            Done
          </button>
        </motion.div>
      )}
    </div>
  );
}
