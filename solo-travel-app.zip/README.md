# Solo Travel App (FREE Hosting Ready)

1. Upload this folder to GitHub.
2. Go to netlify.com → Import from GitHub.
3. Deploy.
4. Your app goes live instantly.
